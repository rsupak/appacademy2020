class Code
  attr_reader :pegs
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  def self.valid_pegs?(pegs)
    pegs.all? { |p| POSSIBLE_PEGS.include?(p.upcase) }
  end

  def initialize(pegs)
    raise unless Code.valid_pegs?(pegs)

    @pegs = pegs.map(&:upcase)
  end

  def self.random(length)
    Code.new(Array.new(length) { POSSIBLE_PEGS.keys.sample })
  end

  def self.from_string(code_string)
    Code.new(code_string.split('').map(&:upcase))
  end

  def [](index)
    @pegs[index]
  end

  def length
    @pegs.size
  end

  def num_exact_matches(guess)
    matches = 0
    (0...guess.length).each { |i| matches += 1 if guess[i] == self[i] }
    matches
  end

  def num_near_matches(guess)
    return 0 if self == guess
    count = 0
    guess.pegs.each.with_index do |peg, i|
      count += 1 if @pegs.include?(peg) && peg != pegs[i]
    end
    count
    
  end

  def ==(other)
    other.length == length && num_exact_matches(other) == length
  end
end
